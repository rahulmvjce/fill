document.addEventListener('DOMContentLoaded', function() {
    // Add event listener for the submit button
    document.getElementById('submitBtn').addEventListener('click', submitForm);

    // Add event listener to update passenger details on change of passenger count
    document.getElementById('passengerCount').addEventListener('change', updatePassengerDetails);

    // Add event listener for the group selection
    document.getElementById('groupSelect').addEventListener('change', function() {
        const selectedGroup = this.value;
        chrome.storage.local.set({ selectedGroup }, function() {
            if (chrome.runtime.lastError) {
                console.error('Error saving selected group:', chrome.runtime.lastError);
            } else {
                loadStoredData();
            }
        });
    });

    // Set the group select to the saved group or default to group1
    chrome.storage.local.get('selectedGroup', function(data) {
        if (data.selectedGroup) {
            document.getElementById('groupSelect').value = data.selectedGroup;
        } else {
            document.getElementById('groupSelect').value = 'group1';
        }

        // Initialize passenger details for default passenger count (1)
        updatePassengerDetails();

        // Load stored data on popup open
        loadStoredData();
    });
});

function updatePassengerDetails() {
    const passengerCount = parseInt(document.getElementById('passengerCount').value, 10);
    const container = document.getElementById('passengerDetailsContainer');
    container.innerHTML = ''; // Clear previous contents

    // Loop to generate fields for each passenger
    for (let i = 1; i <= passengerCount; i++) {
        const passengerHtml = `
            <h3>Passenger ${i}</h3>
            <label for="passenger${i}Name">Name:</label>
            <input type="text" id="passenger${i}Name" name="passenger${i}Name" required>
            <label for="passenger${i}Age">Age:</label>
            <input type="number" id="passenger${i}Age" name="passenger${i}Age" required>
            <label for="passenger${i}Gender">Gender:</label>
            <select id="passenger${i}Gender" name="passenger${i}Gender" required>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
            </select>
            <label for="passenger${i}IdProofType">ID Proof Type:</label>
            <select id="passenger${i}IdProofType" name="passenger${i}IdProofType" required>
                <option value="Aadhaar Card">Aadhaar Card</option>
                <option value="Passport">Passport</option>
                <!-- Add other options as needed -->
            </select>
            <label for="passenger${i}IdProofNumber">ID Proof Number:</label>
            <input type="text" id="passenger${i}IdProofNumber" name="passenger${i}IdProofNumber" required>
            <br><br>
        `;
        container.insertAdjacentHTML('beforeend', passengerHtml);
    }

    // Load stored data when updating passenger details
    loadStoredData();
}

function submitForm() {
    const data = {};
    const group = document.getElementById('groupSelect').value;

    // Loop to gather details for each passenger
    const passengerCount = parseInt(document.getElementById('passengerCount').value, 10);
    for (let i = 1; i <= passengerCount; i++) {
        const passengerName = document.getElementById(`passenger${i}Name`).value.trim();
        const passengerAge = document.getElementById(`passenger${i}Age`).value.trim();
        const passengerGender = document.getElementById(`passenger${i}Gender`).value.trim();
        const passengerIdProofType = document.getElementById(`passenger${i}IdProofType`).value.trim();
        const passengerIdProofNumber = document.getElementById(`passenger${i}IdProofNumber`).value.trim();

        data[`passenger${i}Name`] = passengerName;
        data[`passenger${i}Age`] = passengerAge;
        data[`passenger${i}Gender`] = passengerGender;
        data[`passenger${i}IdProofType`] = passengerIdProofType;
        data[`passenger${i}IdProofNumber`] = passengerIdProofNumber;
    }

    // Retrieve the existing data from local storage, update the relevant group, and store it back
    chrome.storage.local.get('pilgrimDetails', function(result) {
        const pilgrimDetails = result.pilgrimDetails || {};
        pilgrimDetails[group] = data;

        chrome.storage.local.set({ pilgrimDetails }, function() {
            if (chrome.runtime.lastError) {
                console.error('Failed to store data:', chrome.runtime.lastError);
            } else {
                console.log('Pilgrim details saved for', group, ':', data);
            }
        });
    });

    // Execute content script to inject data into the target page
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            files: ['content.js']
        }, () => {
            if (chrome.runtime.lastError) {
                console.error('Script injection failed:', chrome.runtime.lastError.message);
            } else {
                console.log('Content script executed');
            }
        });
    });
}

function loadStoredData() {
    const group = document.getElementById('groupSelect').value;

    chrome.storage.local.get(['pilgrimDetails', 'selectedGroup'], function(data) {
        if (chrome.runtime.lastError) {
            console.error('Error accessing storage:', chrome.runtime.lastError);
        } else if (data.pilgrimDetails && data.pilgrimDetails[group]) {
            const details = data.pilgrimDetails[group];
            console.log('Loaded details for group', group, details);

            // Fill form fields with stored data
            const passengerCount = parseInt(document.getElementById('passengerCount').value, 10);
            for (let i = 1; i <= passengerCount; i++) {
                document.getElementById(`passenger${i}Name`).value = details[`passenger${i}Name`] || '';
                document.getElementById(`passenger${i}Age`).value = details[`passenger${i}Age`] || '';
                document.getElementById(`passenger${i}Gender`).value = details[`passenger${i}Gender`] || '';
                document.getElementById(`passenger${i}IdProofType`).value = details[`passenger${i}IdProofType`] || '';
                document.getElementById(`passenger${i}IdProofNumber`).value = details[`passenger${i}IdProofNumber`] || '';
            }
        } else {
            console.log('No details found for group', group);
        }
    });
}
