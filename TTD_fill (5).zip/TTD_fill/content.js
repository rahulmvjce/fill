chrome.storage.local.get(['pilgrimDetails', 'selectedGroup'], function(data) {
    if (chrome.runtime.lastError) {
        console.error('Error accessing storage:', chrome.runtime.lastError);
    } else if (data.pilgrimDetails && data.selectedGroup) {
        const details = data.pilgrimDetails[data.selectedGroup];
        console.log('Retrieved pilgrim details for group', data.selectedGroup, details);

        // Check if we are on the correct page
        if (window.location.href.includes('ttdevasthanams.ap.gov.in/')) {
            console.log('On the pilgrim details page, filling in details...');
            try {
                // Function to fill details for each passenger
                const fillPassengerDetails = (passengerIndex, details) => {
                    const nameField = document.querySelector(`input[name="fname"][id="${passengerIndex}"]`);
                    const ageField = document.querySelector(`input[name="age"][id="${passengerIndex}"]`);
                    const genderField = document.querySelector(`input[name="gender"][id="${passengerIndex}"]`);
                    const idProofTypeField = document.querySelector(`input[name="photoIdType"][id="${passengerIndex}"]`);
                    const idProofNumberField = document.querySelector(`input[name="idProofNumber"][id="${passengerIndex}"]`);

                    if (nameField) {
                        nameField.value = details[`passenger${passengerIndex + 1}Name`];
                        nameField.dispatchEvent(new Event('input', { bubbles: true }));
                        nameField.dispatchEvent(new Event('change', { bubbles: true }));
                        console.log(`Filled Name for Passenger ${passengerIndex + 1}:`, details[`passenger${passengerIndex + 1}Name`]);
                    } else {
                        console.error(`Name field not found for Passenger ${passengerIndex + 1}.`);
                    }

                    if (ageField) {
                        ageField.value = details[`passenger${passengerIndex + 1}Age`];
                        ageField.dispatchEvent(new Event('input', { bubbles: true }));
                        ageField.dispatchEvent(new Event('change', { bubbles: true }));
                        console.log(`Filled Age for Passenger ${passengerIndex + 1}:`, details[`passenger${passengerIndex + 1}Age`]);
                    } else {
                        console.error(`Age field not found for Passenger ${passengerIndex + 1}.`);
                    }

                    if (genderField) {
                        // Simulate a click on the gender field to open the dropdown
                        genderField.click();
                        // Delay to ensure dropdown is fully opened
                        setTimeout(() => {
                            // Select the appropriate option based on the value from storage
                            const genderOptions = document.querySelectorAll('.floatingDropdown_listItem__tU_5x');
                            for (const option of genderOptions) {
                                if (option.textContent.trim() === details[`passenger${passengerIndex + 1}Gender`]) {
                                    option.click();
                                    console.log(`Selected Gender "${details[`passenger${passengerIndex + 1}Gender`]}" for Passenger ${passengerIndex + 1}`);
                                    break;
                                }
                            }
                        }, 500); // Adjust delay as needed
                    } else {
                        console.error(`Gender field not found for Passenger ${passengerIndex + 1}.`);
                    }

                    if (idProofTypeField) {
                        // Simulate a click on the ID proof type field to open the dropdown
                        idProofTypeField.click();
                        // Delay to ensure dropdown is fully opened
                        setTimeout(() => {
                            // Select the appropriate option based on the value from storage
                            const idProofTypeOptions = document.querySelectorAll('.floatingDropdown_listItem__tU_5x');
                            for (const option of idProofTypeOptions) {
                                if (option.textContent.trim() === details[`passenger${passengerIndex + 1}IdProofType`]) {
                                    option.click();
                                    console.log(`Selected ID Proof Type "${details[`passenger${passengerIndex + 1}IdProofType`]}" for Passenger ${passengerIndex + 1}`);
                                    
                                    // Fill ID proof number AFTER the ID proof type is selected
                                    setTimeout(() => {
                                        if (idProofNumberField) {
                                            idProofNumberField.value = details[`passenger${passengerIndex + 1}IdProofNumber`];
                                            idProofNumberField.dispatchEvent(new Event('input', { bubbles: true }));
                                            idProofNumberField.dispatchEvent(new Event('change', { bubbles: true }));
                                            console.log(`Filled ID Proof Number for Passenger ${passengerIndex + 1}:`, details[`passenger${passengerIndex + 1}IdProofNumber`]);
                                        } else {
                                            console.error(`ID Proof Number field not found for Passenger ${passengerIndex + 1}.`);
                                        }
                                    }, 300);
                                    break;
                                }
                            }
                        }, 500); // Adjust delay as needed
                    } else {
                        console.error(`ID Proof Type field not found for Passenger ${passengerIndex + 1}.`);
                    }
                };

                // Fill details for all passengers
                for (let i = 0; i < Object.keys(details).length / 5; i++) {
                    fillPassengerDetails(i, details);
                }
            } catch (error) {
                console.error('Error filling pilgrim details:', error);
            }
        } else {
            console.log('Not on the pilgrim details page.');
        }
    } else {
        console.error('No pilgrim details found in storage.');
    }
});
