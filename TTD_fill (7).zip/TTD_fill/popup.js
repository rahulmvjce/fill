document.addEventListener('DOMContentLoaded', function() {
    // Add event listeners
    document.getElementById('fillBtn').addEventListener('click', fillForm);
    document.getElementById('optionsBtn').addEventListener('click', openOptions);
    document.getElementById('groupSelect').addEventListener('change', function() {
        const selectedGroup = this.value;
        chrome.storage.local.set({ selectedGroup }, function() {
            if (chrome.runtime.lastError) {
                console.error('Error saving selected group:', chrome.runtime.lastError);
            } else {
                updateDataStatus();
            }
        });
    });

    // Initialize popup
    initializePopup();
});

function initializePopup() {
    // Load the selected group
    chrome.storage.local.get('selectedGroup', function(data) {
        if (data.selectedGroup) {
            document.getElementById('groupSelect').value = data.selectedGroup;
        } else {
            document.getElementById('groupSelect').value = 'group1';
            chrome.storage.local.set({ selectedGroup: 'group1' });
        }
        updateDataStatus();
    });
}

function updateDataStatus() {
    const group = document.getElementById('groupSelect').value;
    const statusDiv = document.getElementById('dataStatus');
    const statusText = document.getElementById('statusText');
    const fillBtn = document.getElementById('fillBtn');

    chrome.storage.local.get(['pilgrimDetails'], function(data) {
        if (chrome.runtime.lastError) {
            console.error('Error accessing storage:', chrome.runtime.lastError);
            statusText.textContent = 'Error loading data';
            statusDiv.className = 'data-status no-data';
            fillBtn.disabled = true;
        } else if (data.pilgrimDetails && data.pilgrimDetails[group]) {
            const details = data.pilgrimDetails[group];
            // Count passengers
            const passengerCount = Math.floor((Object.keys(details).length - 5) / 5);
            
            statusText.textContent = `Ready: ${passengerCount} passenger(s) configured`;
            statusDiv.className = 'data-status has-data';
            fillBtn.disabled = false;
        } else {
            statusText.textContent = `No data for ${group}`;
            statusDiv.className = 'data-status no-data';
            fillBtn.disabled = true;
        }
    });
}

function fillForm() {
    const fillBtn = document.getElementById('fillBtn');
    const originalText = fillBtn.innerHTML;
    
    // Show loading state
    fillBtn.innerHTML = '<span class="btn-icon">⏳</span> Filling...';
    fillBtn.disabled = true;

    // Check if we're on the correct tab
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        const currentTab = tabs[0];
        
        if (!currentTab.url.includes('ttdevasthanams.ap.gov.in/')) {
            alert('Please navigate to the TTD pilgrim details page first!');
            fillBtn.innerHTML = originalText;
            fillBtn.disabled = false;
            return;
        }

        // Execute the content script
        chrome.scripting.executeScript({
            target: { tabId: currentTab.id },
            files: ['content.js']
        }, (results) => {
            if (chrome.runtime.lastError) {
                console.error('Script injection failed:', chrome.runtime.lastError.message);
                alert('Failed to fill form. Please try again.');
            } else {
                console.log('Content script executed successfully');
                // Close popup after successful execution
                setTimeout(() => {
                    window.close();
                }, 1000);
            }
            
            // Restore button state
            fillBtn.innerHTML = originalText;
            fillBtn.disabled = false;
        });
    });
}

function openOptions() {
    chrome.tabs.create({
        url: chrome.runtime.getURL('options.html')
    });
}
