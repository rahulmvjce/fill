chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.set({ selectedGroup: 'group1' });
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'setGroup') {
        chrome.storage.local.set({ selectedGroup: request.group });
    }
});
