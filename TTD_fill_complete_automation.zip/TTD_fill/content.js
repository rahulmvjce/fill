chrome.storage.local.get(['pilgrimDetails', 'selectedGroup'], function(data) {
    if (chrome.runtime.lastError) {
        console.error('Error accessing storage:', chrome.runtime.lastError);
    } else if (data.pilgrimDetails && data.selectedGroup) {
        const details = data.pilgrimDetails[data.selectedGroup];
        console.log('Retrieved pilgrim details for group', data.selectedGroup, details);

        // Slot booking date selection and ticket count
        if (window.location.pathname.includes('/slot-booking') || window.location.pathname.includes('/spat/slot-booking')) {
            console.log('On slot booking page, attempting to select date and tickets...');
            
            // Calculate passenger count from stored details
            const passengerCount = Math.floor((Object.keys(details).length - 7) / 5); // Exclude emailId, slotDate, slotTime, city, state, country, and pincode
            console.log(`Passenger count: ${passengerCount}`);
            
            // Wait for page to load, then select date
            setTimeout(() => {
                if (details.slotDate) {
                    // Format date for id lookup: 'YYYY-MM-DD' to 'DD/MM'
                    // Note: The month in the ID is 0-indexed (like JavaScript Date.getMonth())
                    const dateObj = new Date(details.slotDate);
                    const day = dateObj.getDate();
                    const month = dateObj.getMonth(); // Keep it 0-indexed (0=Jan, 9=Oct, 10=Nov)
                    
                    // Try different formats
                    const dateId1 = `${day}/${month}`; // e.g., "19/10" for Nov 19
                    const dateId2 = `${String(day).padStart(2, '0')}/${String(month).padStart(2, '0')}`; // e.g., "19/10"
                    
                    console.log(`Looking for date cell with IDs: ${dateId1} or ${dateId2} (for date: ${details.slotDate})`);
                    
                    let dateCell = document.getElementById(dateId1);
                    if (!dateCell) {
                        dateCell = document.getElementById(dateId2);
                    }
                    
                    if (dateCell) {
                        const style = dateCell.getAttribute('style');
                        console.log(`Found date cell with style: ${style}`);
                        
                        if (style && style.includes('pointer-events: auto')) {
                            dateCell.click();
                            console.log(`Date ${dateId1} clicked successfully.`);
                            
                            // After clicking date, wait and then select ticket count
                            setTimeout(() => {
                                selectTicketCount(passengerCount);
                            }, 1000);
                        } else if (style && style.includes('pointer-events: none')) {
                            console.log(`Date ${dateId1} is not selectable (already selected or unavailable).`);
                            // Still try to select tickets if date is already selected
                            setTimeout(() => {
                                selectTicketCount(passengerCount);
                            }, 500);
                        } else {
                            // Try clicking anyway
                            dateCell.click();
                            console.log(`Date ${dateId1} clicked (no pointer-events check).`);
                            setTimeout(() => {
                                selectTicketCount(passengerCount);
                            }, 1000);
                        }
                    } else {
                        console.error(`Date cell not found for ${dateId1} or ${dateId2}. Available date cells:`, 
                            Array.from(document.querySelectorAll('td[id]')).map(td => td.id).slice(0, 20));
                    }
                } else {
                    console.log('No slot booking date found in details.');
                }
            }, 1500); // Wait 1.5 seconds for page to fully load
            return;
        }
        
        // Function to select ticket count
        function selectTicketCount(count) {
            console.log(`Attempting to select ${count} tickets...`);
            
            // Look for the ticket count input field
            const ticketInput = document.querySelector('input.floating-input[readonly]');
            
            if (ticketInput) {
                console.log('Found ticket input field');
                
                // Click on the input to open dropdown
                ticketInput.click();
                
                // Wait for dropdown to appear
                setTimeout(() => {
                    // Look for dropdown items - they might be in a list
                    const dropdownItems = document.querySelectorAll('.floatingDropdown_listItem__tU_5x, .dropdown-item, li[role="option"]');
                    console.log(`Found ${dropdownItems.length} dropdown items`);
                    
                    // Find the item with the matching count
                    for (const item of dropdownItems) {
                        const itemText = item.textContent.trim();
                        console.log(`Checking dropdown item: "${itemText}"`);
                        
                        if (itemText === count.toString() || itemText === `${count}`) {
                            item.click();
                            console.log(`Selected ${count} tickets successfully.`);
                            
                            // After selecting tickets, wait and then select time slot
                            setTimeout(() => {
                                selectTimeSlot(details.slotTime);
                            }, 1000);
                            return;
                        }
                    }
                    
                    console.error(`Could not find dropdown item for ${count} tickets. Available items:`, 
                        Array.from(dropdownItems).map(item => item.textContent.trim()));
                }, 500);
            } else {
                console.error('Ticket input field not found. Looking for alternatives...');
                
                // Try alternative selectors
                const allInputs = document.querySelectorAll('input[readonly]');
                console.log(`Found ${allInputs.length} readonly inputs:`, 
                    Array.from(allInputs).map(input => ({value: input.value, class: input.className})));
            }
        }
        
        // Function to select time slot
        function selectTimeSlot(timeValue) {
            if (!timeValue) {
                console.log('No time slot specified in details.');
                return;
            }
            
            console.log(`Attempting to select time slot: ${timeValue}...`);
            
            // Look for the time slot button with the matching value
            const timeButton = document.querySelector(`button[value="${timeValue}"]`);
            
            if (timeButton) {
                console.log(`Found time slot button for ${timeValue}`);
                timeButton.click();
                console.log(`Time slot ${timeValue} clicked successfully.`);
                
                // After selecting time slot, wait and then click Continue button
                setTimeout(() => {
                    clickContinueButton();
                }, 1000);
            } else {
                console.error(`Time slot button not found for value: ${timeValue}`);
                
                // Log all available time slot buttons for debugging
                const allButtons = document.querySelectorAll('button[value]');
                console.log(`Found ${allButtons.length} buttons with value attribute:`, 
                    Array.from(allButtons).map(btn => btn.value).slice(0, 24));
            }
        }
        
        // Function to click the Continue button
        function clickContinueButton() {
            console.log('Attempting to click Continue button...');
            
            // Look for the Continue button
            const continueButton = document.querySelector('button.SlotBooking_darkpurpleDesktopButton__ja4Nq');
            
            if (continueButton) {
                console.log('Found Continue button');
                continueButton.click();
                console.log('Continue button clicked successfully!');
                
                // After clicking Continue, wait for navigation and then fill form
                console.log('Waiting for navigation to pilgrim details page...');
                waitForPilgrimDetailsPageAndFill();
            } else {
                console.error('Continue button not found. Looking for alternatives...');
                
                // Try alternative selectors
                const allButtons = document.querySelectorAll('button');
                const continueBtn = Array.from(allButtons).find(btn => 
                    btn.textContent.trim().toLowerCase() === 'continue'
                );
                
                if (continueBtn) {
                    continueBtn.click();
                    console.log('Continue button clicked using text search!');
                    console.log('Waiting for navigation to pilgrim details page...');
                    waitForPilgrimDetailsPageAndFill();
                } else {
                    console.error('Continue button not found with any method. Available buttons:', 
                        Array.from(allButtons).map(btn => ({
                            text: btn.textContent.trim(),
                            class: btn.className
                        })).slice(0, 10));
                }
            }
        }
        
        // Function to wait for pilgrim details page and then fill the form
        function waitForPilgrimDetailsPageAndFill() {
            const checkInterval = setInterval(() => {
                if (window.location.pathname.includes('/pilgrim-details') || window.location.pathname.includes('/spat/pilgrim-details')) {
                    console.log('Navigated to pilgrim details page!');
                    clearInterval(checkInterval);
                    
                    // Wait a bit more for the page to fully load
                    setTimeout(() => {
                        fillPilgrimDetailsForm();
                    }, 2000);
                }
            }, 500); // Check every 500ms
            
            // Stop checking after 10 seconds
            setTimeout(() => {
                clearInterval(checkInterval);
                console.log('Stopped waiting for pilgrim details page navigation.');
            }, 10000);
        }
        
        // Function to fill pilgrim details form
        function fillPilgrimDetailsForm() {
            console.log('Starting to fill pilgrim details form...');
            try {
                // Fill email field first
                const emailField = document.querySelector('input[name="emailId"]');
                if (emailField && details.emailId) {
                    emailField.value = details.emailId;
                    emailField.dispatchEvent(new Event('input', { bubbles: true }));
                    emailField.dispatchEvent(new Event('change', { bubbles: true }));
                    console.log('Filled Email ID:', details.emailId);
                } else if (!emailField) {
                    console.error('Email field not found.');
                } else {
                    console.log('No email ID provided in details.');
                }

                // Fill city field
                const cityField = document.querySelector('input[name="city"]');
                if (cityField && details.city) {
                    cityField.value = details.city;
                    cityField.dispatchEvent(new Event('input', { bubbles: true }));
                    cityField.dispatchEvent(new Event('change', { bubbles: true }));
                    console.log('Filled City:', details.city);
                } else if (!cityField) {
                    console.error('City field not found.');
                } else {
                    console.log('No city provided in details.');
                }

                // Fill state field
                const stateField = document.querySelector('input[name="state"]');
                if (stateField && details.state) {
                    stateField.value = details.state;
                    stateField.dispatchEvent(new Event('input', { bubbles: true }));
                    stateField.dispatchEvent(new Event('change', { bubbles: true }));
                    console.log('Filled State:', details.state);
                } else if (!stateField) {
                    console.error('State field not found.');
                } else {
                    console.log('No state provided in details.');
                }

                // Fill country field
                const countryField = document.querySelector('input[name="country"]');
                if (countryField && details.country) {
                    countryField.value = details.country;
                    countryField.dispatchEvent(new Event('input', { bubbles: true }));
                    countryField.dispatchEvent(new Event('change', { bubbles: true }));
                    console.log('Filled Country:', details.country);
                } else if (!countryField) {
                    console.error('Country field not found.');
                } else {
                    console.log('No country provided in details.');
                }

                // Fill pincode field
                const pincodeField = document.querySelector('input[name="pincode"]');
                if (pincodeField && details.pincode) {
                    pincodeField.value = details.pincode;
                    pincodeField.dispatchEvent(new Event('input', { bubbles: true }));
                    pincodeField.dispatchEvent(new Event('change', { bubbles: true }));
                    console.log('Filled Pincode:', details.pincode);
                } else if (!pincodeField) {
                    console.error('Pincode field not found.');
                } else {
                    console.log('No pincode provided in details.');
                }

                // Function to fill details for each passenger
                const fillPassengerDetails = (passengerIndex, details) => {
                    const nameField = document.querySelector(`input[name="fname"][id="${passengerIndex}"]`);
                    const ageField = document.querySelector(`input[name="age"][id="${passengerIndex}"]`);
                    const genderField = document.querySelector(`input[name="gender"][id="${passengerIndex}"]`);
                    const idProofTypeField = document.querySelector(`input[name="photoIdType"][id="${passengerIndex}"]`);
                    const idProofNumberField = document.querySelector(`input[name="idProofNumber"][id="${passengerIndex}"]`);

                    if (nameField) {
                        nameField.value = details[`passenger${passengerIndex + 1}Name`];
                        nameField.dispatchEvent(new Event('input', { bubbles: true }));
                        nameField.dispatchEvent(new Event('change', { bubbles: true }));
                        console.log(`Filled Name for Passenger ${passengerIndex + 1}:`, details[`passenger${passengerIndex + 1}Name`]);
                    } else {
                        console.error(`Name field not found for Passenger ${passengerIndex + 1}.`);
                    }

                    if (ageField) {
                        ageField.value = details[`passenger${passengerIndex + 1}Age`];
                        ageField.dispatchEvent(new Event('input', { bubbles: true }));
                        ageField.dispatchEvent(new Event('change', { bubbles: true }));
                        console.log(`Filled Age for Passenger ${passengerIndex + 1}:`, details[`passenger${passengerIndex + 1}Age`]);
                    } else {
                        console.error(`Age field not found for Passenger ${passengerIndex + 1}.`);
                    }

                    if (genderField) {
                        // Simulate a click on the gender field to open the dropdown
                        genderField.click();
                        // Delay to ensure dropdown is fully opened
                        setTimeout(() => {
                            // Select the appropriate option based on the value from storage
                            const genderOptions = document.querySelectorAll('.floatingDropdown_listItem__tU_5x');
                            for (const option of genderOptions) {
                                if (option.textContent.trim() === details[`passenger${passengerIndex + 1}Gender`]) {
                                    option.click();
                                    console.log(`Selected Gender "${details[`passenger${passengerIndex + 1}Gender`]}" for Passenger ${passengerIndex + 1}`);
                                    break;
                                }
                            }
                        }, 500); // Adjust delay as needed
                    } else {
                        console.error(`Gender field not found for Passenger ${passengerIndex + 1}.`);
                    }

                    if (idProofTypeField) {
                        // Simulate a click on the ID proof type field to open the dropdown
                        idProofTypeField.click();
                        // Delay to ensure dropdown is fully opened
                        setTimeout(() => {
                            // Select Aadhaar Card option (since it's the only option we support)
                            const idProofTypeOptions = document.querySelectorAll('.floatingDropdown_listItem__tU_5x');
                            for (const option of idProofTypeOptions) {
                                if (option.textContent.trim() === 'Aadhaar Card') {
                                    option.click();
                                    console.log(`Selected ID Proof Type "Aadhaar Card" for Passenger ${passengerIndex + 1}`);
                                    
                                    // Fill Aadhaar number AFTER the ID proof type is selected
                                    setTimeout(() => {
                                        if (idProofNumberField) {
                                            idProofNumberField.value = details[`passenger${passengerIndex + 1}IdProofNumber`];
                                            idProofNumberField.dispatchEvent(new Event('input', { bubbles: true }));
                                            idProofNumberField.dispatchEvent(new Event('change', { bubbles: true }));
                                            console.log(`Filled Aadhaar Number for Passenger ${passengerIndex + 1}:`, details[`passenger${passengerIndex + 1}IdProofNumber`]);
                                        } else {
                                            console.error(`Aadhaar Number field not found for Passenger ${passengerIndex + 1}.`);
                                        }
                                    }, 300);
                                    break;
                                }
                            }
                        }, 500); // Adjust delay as needed
                    } else {
                        console.error(`ID Proof Type field not found for Passenger ${passengerIndex + 1}.`);
                    }
                };

                // Fill details for all passengers
                const passengerCount = Math.floor((Object.keys(details).length - 7) / 5); // Exclude emailId, slotDate, slotTime, city, state, country, and pincode from count
                for (let i = 0; i < passengerCount; i++) {
                    fillPassengerDetails(i, details);
                }

                // After filling all details, wait and then click the Continue button
                setTimeout(() => {
                    clickPilgrimDetailsContinueButton();
                }, 3000); // Wait 3 seconds after form filling
            } catch (error) {
                console.error('Error filling pilgrim details:', error);
            }
        }

        // Function to click Continue button on pilgrim-details page
        function clickPilgrimDetailsContinueButton() {
            console.log('Attempting to click Continue button on pilgrim-details page...');
            
            // Look for the Continue button
            const continueButton = document.querySelector('button.primary-btn');
            
            if (continueButton && continueButton.textContent.trim() === 'Continue') {
                console.log('Found pilgrim-details Continue button');
                continueButton.click();
                console.log('Pilgrim-details Continue button clicked successfully!');
            } else {
                console.error('Pilgrim-details Continue button not found');
                
                // Log all buttons with primary-btn class for debugging
                const allPrimaryButtons = document.querySelectorAll('button.primary-btn');
                console.log(`Found ${allPrimaryButtons.length} buttons with primary-btn class:`, 
                    Array.from(allPrimaryButtons).map(btn => ({
                        text: btn.textContent.trim(),
                        classes: btn.className
                    })));
                
                // Try alternative selectors
                const allButtons = document.querySelectorAll('button');
                const continueButtons = Array.from(allButtons).filter(btn => 
                    btn.textContent.trim().toLowerCase().includes('continue'));
                
                if (continueButtons.length > 0) {
                    console.log('Found alternative Continue buttons:', 
                        continueButtons.map(btn => ({
                            text: btn.textContent.trim(),
                            classes: btn.className
                        })));
                    
                    // Click the first Continue button found
                    continueButtons[0].click();
                    console.log('Alternative Continue button clicked!');
                } else {
                    console.error('No Continue buttons found on the page');
                }
            }
        }

        // Fill pilgrim details on page load if already on pilgrim details page
        if (window.location.pathname.includes('/pilgrim-details') || window.location.pathname.includes('/spat/pilgrim-details')) {
            console.log('On pilgrim details page on load, preparing to fill form...');
            setTimeout(() => {
                fillPilgrimDetailsForm();
            }, 1500);
        }
    } else {
        console.error('No pilgrim details found in storage.');
    }
});
