# Complete TTD Booking Automa### 3. **content.js** - Auto-Select Date, Tickets, Time Slot, and Auto-Fill Forms
- Added detection for the slot booking page URL
- Converts date from `YYYY-MM-DD` format to `DD/MM` format (matches the page's date cell IDs)
- Calculates passenger count from stored details
- **Slot Booking Automation:**
  - Waits 1.5 seconds for the page to load before attempting to select the date
  - After selecting the date, automatically selects the number of tickets
  - After selecting tickets, automatically clicks the time slot button with matching value
  - After selecting time slot, clicks the "Continue" button
  - **Monitors URL for navigation to pilgrim-details page**
  - **Automatically fills form when pilgrim-details page loads**
- **Pilgrim Details Automation:**
  - Detects when on pilgrim-details page (both on direct load and after navigation)
  - Waits 2 seconds after navigation for page to fully load
  - Automatically fills all passenger and common details
- Provides detailed console logging for debugging all stepsull Implementation

## What Was Added

The extension now provides **end-to-end automation** for TTD slot booking:

### Slot Booking Page:
1. Selects your preferred booking date on the slot booking page
2. Automatically selects the number of tickets matching your passenger count
3. Automatically selects your preferred time slot (24-hour format)
4. Automatically clicks the "Continue" button to proceed to passenger details

### Pilgrim Details Page (After Continue):
5. Automatically fills all passenger details (name, age, gender, ID proof, Aadhaar)
6. Automatically fills common details (email, city, state, country, pincode)
7. Ready for you to review and submit!

## Changes Made

### 1. **options.html** - Added Date and Time Input Fields
- Added a date picker field labeled "Slot Booking Date"
- Added a dropdown for time slot selection with all 24 hourly slots (00:00 to 23:00)
- This allows users to select their desired booking date and time from intuitive interfaces

### 2. **options.js** - Save and Load Date & Time
- Modified `submitForm()` to save the selected date and time to Chrome storage
- Modified `loadStoredData()` to load the saved date and time when viewing options
- Updated validation to require both the slot date and time fields

### 3. **content.js** - Auto-Select Date, Tickets, and Time Slot
- Added detection for the slot booking page URL
- Converts date from `YYYY-MM-DD` format to `DD/MM` format (matches the page's date cell IDs)
- Calculates passenger count from stored details
- Waits 1.5 seconds for the page to load before attempting to select the date
- After selecting the date, automatically selects the number of tickets
- After selecting tickets, automatically clicks the time slot button with matching value
- Provides detailed console logging for debugging all steps

### 4. **manifest.json** - Added Slot Booking Page Permission
- Added `https://ttdevasthanams.ap.gov.in/spat/slot-booking*` to content script matches
- This allows the extension to run on the slot booking page

### 5. **popup.js** - Updated Passenger Count Calculation
- Fixed passenger count calculation to exclude the new `slotDate` and `slotTime` fields (now excludes 7 fields instead of 6)

## How to Use

1. **Open Extension Options**
   - Click the extension icon in Chrome
   - Click "Manage Details" button

2. **Enter Your Details**
   - Select the number of passengers (e.g., 4 passengers)
   - Select your booking date in the "Slot Booking Date" field (e.g., 19/11/2025)
   - Select your preferred time slot (e.g., "08:00 AM (08:00)" for 8 AM slot)
   - Fill in all passenger details (name, age, gender, Aadhaar, etc.)
   - Fill in common details (email, city, state, country, pincode)
   - Click "Save Details"

3. **Navigate to Slot Booking Page**
   - Go to: https://ttdevasthanams.ap.gov.in/spat/slot-booking?flow=spat&flowIdentifier=spat
   - Or use the extension popup "Fill Form" button when already on the page

4. **Watch the Complete Automation**
   
   **On Slot Booking Page:**
   - The extension will automatically:
     1. Wait 1.5 seconds for the page to load
     2. Click on your selected date
     3. Wait 1 second after date selection
     4. Click the ticket count dropdown
     5. Select the number of tickets matching your passenger count (e.g., 4 tickets)
     6. Wait 1 second after ticket selection
     7. Click the time slot button with your selected time (e.g., button with value="0800")
     8. Wait 1 second after time slot selection
     9. Click the "Continue" button
     10. Navigate to the pilgrim details page automatically!
   
   **On Pilgrim Details Page (Automatic):**
   - After clicking Continue, you'll be redirected to the pilgrim details page
   - The extension will automatically (after 1.5 seconds):
     11. Fill all passenger details (name, age, gender, ID proof, Aadhaar)
     12. Fill common details (email, city, state, country, pincode)
     13. All done - ready for you to review and submit!
   
   - Check the browser console (F12) for detailed logs about the entire process

## Technical Details

### Complete Workflow
**Slot Booking Page:**
1. **Page Load** → Wait 1.5 seconds
2. **Date Selection** → Click date cell (e.g., "19/10" for Nov 19)
3. **Wait** → 1 second delay
4. **Ticket Selection** → Click ticket dropdown and select count (e.g., "4")
5. **Wait** → 1 second delay
6. **Time Slot Selection** → Click time slot button (e.g., value="0800")
7. **Wait** → 1 second delay
8. **Continue Button** → Click the "Continue" button

**Pilgrim Details Page (Automatic Page Load):**
9. **URL Detection** → Extension monitors for URL change to pilgrim-details
10. **Wait for Navigation** → Detects when page URL includes "pilgrim-details"
11. **Page Load Delay** → Wait 2 seconds for page to fully render
12. **Fill Email** → Enter email address
13. **Fill City** → Enter city
14. **Fill State** → Enter state
15. **Fill Country** → Enter country
16. **Fill Pincode** → Enter pincode
17. **Fill Passengers** → For each passenger:
    - Fill name
    - Fill age
    - Select gender (click dropdown, wait 0.5s, select)
    - Select ID proof type (click dropdown, wait 0.5s, select Aadhaar)
    - Fill Aadhaar number (after 0.3s delay)
18. **Continue Button** → Click "Continue" button on pilgrim details page
19. **Complete!** → Proceeds to next step in booking process

### Code Architecture Improvements
- **Dynamic URL Detection**: Uses `window.location.pathname` instead of hardcoded domain URLs
- **Manifest-Driven**: URL patterns defined in `manifest.json`, content script uses path-based detection
- **Maintainable**: Changes to URLs only require updating `manifest.json`
- **Multi-Flow Support**: Works with both SPAT and SED booking flows
  - SPAT Flow: `/spat/slot-booking` → `/spat/pilgrim-details`
  - SED Flow: `/slot-booking` → `/pilgrim-details`

### Passenger Count Calculation
- The extension automatically calculates passenger count from saved details
- Formula: `(total fields - 7 common fields) / 5 fields per passenger`
- Common fields: emailId, slotDate, slotTime, city, state, country, pincode
- Per passenger: name, age, gender, idProofType, idProofNumber

### Time Slot Format
- Options page shows user-friendly format: "08:00 AM (08:00)"
- Stored value: "0800" (4-digit 24-hour format)
- Button selector: `button[value="0800"]`

### Available Time Slots
All 24 hourly slots from midnight to 11 PM:
- 0000 = 12:00 AM
- 0100 = 01:00 AM
- ...
- 0800 = 08:00 AM
- ...
- 1200 = 12:00 PM
- 1300 = 01:00 PM
- ...
- 2300 = 11:00 PM

### Date Cell Selection Logic
1. Checks if the date cell exists on the page
2. Verifies if the date is selectable by checking for `pointer-events: auto` in the style attribute
3. Clicks the date cell if available
4. Triggers ticket selection after date is selected
5. Logs detailed information to console for debugging

### Date Format Conversion
- Input: `2025-11-19` (from HTML date picker)
- Output: `19/10` (matches the page's `<td>` element ID)
- Note: Month is 0-indexed (10 = November)

### Date Cell States
- **Selectable**: `pointer-events: auto` (green background - `rgb(94, 184, 18)`)
- **Not Selectable**: `pointer-events: none` (purple background - `rgb(102, 51, 153)` - already selected or unavailable)

## Console Logs to Look For

### Successful Complete Flow:

**Slot Booking Page:**
1. `"On slot booking page, attempting to select date and tickets..."`
2. `"Passenger count: 4"`
3. `"Looking for date cell with IDs: 19/10 or 19/10 (for date: 2025-11-19)"`
4. `"Found date cell with style: ..."`
5. `"Date 19/10 clicked successfully."`
6. `"Attempting to select 4 tickets..."`
7. `"Found ticket input field"`
8. `"Found X dropdown items"`
9. `"Selected 4 tickets successfully."`
10. `"Attempting to select time slot: 0800..."`
11. `"Found time slot button for 0800"`
12. `"Time slot 0800 clicked successfully."`
13. `"Attempting to click Continue button..."`
14. `"Found Continue button"`
15. `"Continue button clicked successfully!"`
16. `"Waiting for navigation to pilgrim details page..."`
17. `"Navigated to pilgrim details page!"`

**Pilgrim Details Page (After Navigation):**
18. `"Starting to fill pilgrim details form..."`
19. `"Filled Email ID: [email]"`
20. `"Filled City: [city]"`
21. `"Filled State: [state]"`
22. `"Filled Country: [country]"`
23. `"Filled Pincode: [pincode]"`
24. `"Filled Name for Passenger 1: [name]"`
25. `"Filled Age for Passenger 1: [age]"`
26. `"Selected Gender "[gender]" for Passenger 1"`
27. `"Selected ID Proof Type "Aadhaar Card" for Passenger 1"`
28. `"Filled Aadhaar Number for Passenger 1: [number]"`
29. (Repeat for all passengers)

### If Issues Occur:
- `"Date cell not found for ..."`
- `"Ticket input field not found. Looking for alternatives..."`
- `"Could not find dropdown item for X tickets..."`
- `"Time slot button not found for value: 0800"`
- `"Continue button not found. Looking for alternatives..."`
- `"Email field not found."`
- `"Age field not found for Passenger X."`
- Console will show all available buttons/fields if not found

## Troubleshooting

### Date Not Being Selected:
1. Open browser console (F12) and check for error messages
2. Verify the date format in the page's HTML matches your expected date
3. Ensure the date cell has `pointer-events: auto` (meaning it's available)
4. Check if the page loaded completely before the extension tried to select the date
5. You can increase the timeout in `content.js` if needed (currently 1500ms)

### Ticket Count Not Being Selected:
1. Check console for "Found ticket input field" message
2. Verify the dropdown opens when you manually click the ticket field
3. Check the dropdown item selector - it might have a different class name
4. The console will show all available dropdown items if selection fails
5. You can increase the dropdown wait timeout in `content.js` if needed (currently 500ms)

### Time Slot Not Being Selected:
1. Check console for "Found time slot button" message
2. Verify the button exists with the correct value attribute (e.g., `value="0800"`)
3. The console will show all available button values if selection fails
4. Make sure the time slot is available (not already booked)
5. You can increase the wait time between ticket and time selection if needed (currently 1000ms)

### Continue Button Not Being Clicked:
1. Check console for "Found Continue button" message
2. Verify the button has class `SlotBooking_darkpurpleDesktopButton__ja4Nq`
3. The extension will try to find button by text "Continue" as fallback
4. The console will show all available buttons if not found
5. You can increase the wait time after time slot selection if needed (currently 1000ms)

### Form Not Filling After Navigation:
1. Check console for "Waiting for navigation to pilgrim details page..." message
2. Verify "Navigated to pilgrim details page!" appears within 10 seconds
3. The extension checks URL every 500ms for "pilgrim-details"
4. If navigation is detected, it waits 2 seconds before filling
5. Check that the URL includes `pilgrim-details` after clicking Continue
6. If still not working, you can manually click the extension "Fill Form" button on the pilgrim-details page

## Example Complete Flow

For **4 passengers** selecting **November 19, 2025** at **8:00 AM**:

**SLOT BOOKING PAGE:**
1. ✅ Extension loads pilgrim details
2. ✅ Calculates passenger count = 4
3. ✅ Waits 1.5 seconds for page load
4. ✅ Finds date cell with ID "19/10"
5. ✅ Clicks the date cell
6. ✅ Waits 1 second
7. ✅ Clicks ticket input dropdown
8. ✅ Waits 0.5 seconds for dropdown
9. ✅ Finds and clicks "4" in dropdown
10. ✅ Waits 1 second
11. ✅ Finds time slot button with value="0800"
12. ✅ Clicks the 8:00 AM time slot button
13. ✅ Waits 1 second
14. ✅ Finds and clicks "Continue" button
15. ✅ **Monitors URL for navigation...**
16. ✅ **Detects pilgrim-details URL!**

**PILGRIM DETAILS PAGE (AUTOMATIC - NO MANUAL INTERVENTION!):**
17. ✅ URL changed to pilgrim-details detected
18. ✅ Waits 2 seconds for page to fully load
19. ✅ Starts filling form automatically
20. ✅ Fills email field
21. ✅ Fills city field
22. ✅ Fills state field
23. ✅ Fills country field
24. ✅ Fills pincode field
25. ✅ For each passenger (1-4):
    - Fills name ✅
    - Fills age ✅
    - Clicks gender dropdown → selects gender ✅
    - Clicks ID proof dropdown → selects Aadhaar ✅
    - Fills Aadhaar number ✅
26. ✅ **ALL FIELDS FILLED AUTOMATICALLY! Ready to review and submit!** 🎉🎊

**Your only task:** Review the filled information and click the final Submit button!

**Note:** The extension now monitors for URL changes and automatically fills the form when the pilgrim-details page loads after clicking Continue. No need to manually click "Fill Form" again!
