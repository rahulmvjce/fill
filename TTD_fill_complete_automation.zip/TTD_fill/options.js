document.addEventListener('DOMContentLoaded', function() {
    // Add event listeners
    document.getElementById('submitBtn').addEventListener('click', submitForm);
    document.getElementById('clearBtn').addEventListener('click', clearAllData);
    document.getElementById('passengerCount').addEventListener('change', updatePassengerDetails);
    document.getElementById('groupSelect').addEventListener('change', function() {
        const selectedGroup = this.value;
        chrome.storage.local.set({ selectedGroup }, function() {
            if (chrome.runtime.lastError) {
                console.error('Error saving selected group:', chrome.runtime.lastError);
            } else {
                loadStoredData();
            }
        });
    });

    // Initialize the page
    initializePage();
});

function initializePage() {
    // Set the group select to the saved group or default to group1
    chrome.storage.local.get('selectedGroup', function(data) {
        if (data.selectedGroup) {
            document.getElementById('groupSelect').value = data.selectedGroup;
        } else {
            document.getElementById('groupSelect').value = 'group1';
        }

        // Initialize passenger details for default passenger count (1)
        updatePassengerDetails();

        // Load stored data on page open
        loadStoredData();
    });
}

function updatePassengerDetails() {
    const passengerCount = parseInt(document.getElementById('passengerCount').value, 10);
    const container = document.getElementById('passengerDetailsContainer');
    container.innerHTML = ''; // Clear previous contents

    // Loop to generate fields for each passenger
    for (let i = 1; i <= passengerCount; i++) {
        const passengerCard = document.createElement('div');
        passengerCard.className = 'passenger-card';
        
        passengerCard.innerHTML = `
            <h3>Passenger ${i}</h3>
            <div class="passenger-fields">
                <div class="form-field">
                    <label for="passenger${i}Name">Name:</label>
                    <input type="text" id="passenger${i}Name" name="passenger${i}Name" required pattern="[a-zA-Z .]+" title="Only letters, spaces, and dots are allowed">
                </div>
                <div class="form-field">
                    <label for="passenger${i}Age">Age:</label>
                    <input type="number" id="passenger${i}Age" name="passenger${i}Age" required min="1" max="120">
                </div>
                <div class="form-field">
                    <label for="passenger${i}Gender">Gender:</label>
                    <select id="passenger${i}Gender" name="passenger${i}Gender" required>
                        <option value="">Select Gender</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                </div>
                <div class="form-field">
                    <label for="passenger${i}IdProofType">ID Proof Type:</label>
                    <select id="passenger${i}IdProofType" name="passenger${i}IdProofType" required>
                        <option value="Aadhaar Card">Aadhaar Card</option>
                    </select>
                </div>
                <div class="form-field">
                    <label for="passenger${i}IdProofNumber">Aadhaar Number:</label>
                    <input type="text" id="passenger${i}IdProofNumber" name="passenger${i}IdProofNumber" required pattern="[0-9]{12}" title="Enter 12-digit Aadhaar number" maxlength="12" placeholder="123456789012">
                </div>
            </div>
        `;
        container.appendChild(passengerCard);
    }

    // Add input validation event listeners
    addInputValidation();

    // Load stored data when updating passenger details
    loadStoredData();
}

function addInputValidation() {
    const passengerCount = parseInt(document.getElementById('passengerCount').value, 10);
    
    for (let i = 1; i <= passengerCount; i++) {
        // Name validation - only letters, spaces, and dots
        const nameField = document.getElementById(`passenger${i}Name`);
        if (nameField) {
            nameField.addEventListener('input', function(e) {
                // Remove any non-letter, non-space, non-dot characters
                this.value = this.value.replace(/[^a-zA-Z .]/g, '');
            });
        }

        // Aadhaar number validation - only numbers, max 12 digits
        const aadhaarField = document.getElementById(`passenger${i}IdProofNumber`);
        if (aadhaarField) {
            aadhaarField.addEventListener('input', function(e) {
                // Remove any non-numeric characters
                this.value = this.value.replace(/[^0-9]/g, '');
                // Limit to 12 digits
                if (this.value.length > 12) {
                    this.value = this.value.slice(0, 12);
                }
            });
        }
    }
}

function submitForm() {
    const data = {};
    const group = document.getElementById('groupSelect').value;

    // Get common details
    const emailId = document.getElementById('emailId').value.trim();
    const slotDate = document.getElementById('slotDate').value.trim();
    const slotTime = document.getElementById('slotTime').value.trim();
    const city = document.getElementById('city').value.trim();
    const state = document.getElementById('state').value.trim();
    const country = document.getElementById('country').value.trim();
    const pincode = document.getElementById('pincode').value.trim();
    
    data['emailId'] = emailId;
    data['slotDate'] = slotDate;
    data['slotTime'] = slotTime;
    data['city'] = city;
    data['state'] = state;
    data['country'] = country;
    data['pincode'] = pincode;

    // Validate common fields
    if (!emailId || !slotDate || !slotTime || !city || !state || !country || !pincode) {
        showMessage('Please fill all common details fields, including slot date and time.', 'error');
        return;
    }

    // Get passenger details
    const passengerCount = parseInt(document.getElementById('passengerCount').value, 10);
    for (let i = 1; i <= passengerCount; i++) {
        const passengerName = document.getElementById(`passenger${i}Name`).value.trim();
        const passengerAge = document.getElementById(`passenger${i}Age`).value.trim();
        const passengerGender = document.getElementById(`passenger${i}Gender`).value.trim();
        const passengerIdProofType = document.getElementById(`passenger${i}IdProofType`).value.trim();
        const passengerIdProofNumber = document.getElementById(`passenger${i}IdProofNumber`).value.trim();

        // Validate passenger fields
        if (!passengerName || !passengerAge || !passengerGender || !passengerIdProofType || !passengerIdProofNumber) {
            showMessage(`Please fill all fields for Passenger ${i}.`, 'error');
            return;
        }

        // Validate name - only letters, spaces, and dots
        if (!/^[a-zA-Z .]+$/.test(passengerName)) {
            showMessage(`Invalid name for Passenger ${i}. Only letters, spaces, and dots are allowed.`, 'error');
            return;
        }

        // Validate Aadhaar number - exactly 12 digits
        if (!/^[0-9]{12}$/.test(passengerIdProofNumber)) {
            showMessage(`Invalid Aadhaar number for Passenger ${i}. Must be exactly 12 digits.`, 'error');
            return;
        }

        data[`passenger${i}Name`] = passengerName;
        data[`passenger${i}Age`] = passengerAge;
        data[`passenger${i}Gender`] = passengerGender;
        data[`passenger${i}IdProofType`] = passengerIdProofType;
        data[`passenger${i}IdProofNumber`] = passengerIdProofNumber;
    }

    // Save to storage
    chrome.storage.local.get('pilgrimDetails', function(result) {
        const pilgrimDetails = result.pilgrimDetails || {};
        pilgrimDetails[group] = data;

        chrome.storage.local.set({ pilgrimDetails }, function() {
            if (chrome.runtime.lastError) {
                console.error('Failed to store data:', chrome.runtime.lastError);
                showMessage('Failed to save data. Please try again.', 'error');
            } else {
                console.log('Pilgrim details saved for', group, ':', data);
                showMessage(`Details saved successfully for ${group}!`, 'success');
            }
        });
    });
}

function clearAllData() {
    if (confirm('Are you sure you want to clear all data? This action cannot be undone.')) {
        chrome.storage.local.clear(function() {
            if (chrome.runtime.lastError) {
                console.error('Failed to clear data:', chrome.runtime.lastError);
                showMessage('Failed to clear data. Please try again.', 'error');
            } else {
                // Reset to defaults
                document.getElementById('groupSelect').value = 'group1';
                document.getElementById('passengerCount').value = '1';
                chrome.storage.local.set({ selectedGroup: 'group1' });
                
                // Clear all form fields
                document.getElementById('detailsForm').reset();
                updatePassengerDetails();
                
                showMessage('All data cleared successfully!', 'success');
            }
        });
    }
}

function loadStoredData() {
    const group = document.getElementById('groupSelect').value;

    chrome.storage.local.get(['pilgrimDetails', 'selectedGroup'], function(data) {
        if (chrome.runtime.lastError) {
            console.error('Error accessing storage:', chrome.runtime.lastError);
        } else if (data.pilgrimDetails && data.pilgrimDetails[group]) {
            const details = data.pilgrimDetails[group];
            console.log('Loaded details for group', group, details);

            // Fill common fields
            document.getElementById('emailId').value = details['emailId'] || '';
            document.getElementById('slotDate').value = details['slotDate'] || '';
            document.getElementById('slotTime').value = details['slotTime'] || '';
            document.getElementById('city').value = details['city'] || '';
            document.getElementById('state').value = details['state'] || '';
            document.getElementById('country').value = details['country'] || '';
            document.getElementById('pincode').value = details['pincode'] || '';

            // Fill passenger fields
            const passengerCount = parseInt(document.getElementById('passengerCount').value, 10);
            for (let i = 1; i <= passengerCount; i++) {
                const nameField = document.getElementById(`passenger${i}Name`);
                const ageField = document.getElementById(`passenger${i}Age`);
                const genderField = document.getElementById(`passenger${i}Gender`);
                const idProofTypeField = document.getElementById(`passenger${i}IdProofType`);
                const idProofNumberField = document.getElementById(`passenger${i}IdProofNumber`);

                if (nameField) nameField.value = details[`passenger${i}Name`] || '';
                if (ageField) ageField.value = details[`passenger${i}Age`] || '';
                if (genderField) genderField.value = details[`passenger${i}Gender`] || '';
                if (idProofTypeField) idProofTypeField.value = details[`passenger${i}IdProofType`] || '';
                if (idProofNumberField) idProofNumberField.value = details[`passenger${i}IdProofNumber`] || '';
            }
        } else {
            console.log('No details found for group', group);
        }
    });
}

function showMessage(text, type) {
    const messageDiv = document.getElementById('statusMessage');
    messageDiv.textContent = text;
    messageDiv.className = `status-message ${type}`;
    messageDiv.classList.remove('hidden');
    
    // Hide message after 3 seconds
    setTimeout(() => {
        messageDiv.classList.add('hidden');
    }, 3000);
}